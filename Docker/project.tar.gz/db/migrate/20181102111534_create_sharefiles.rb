class CreateSharefiles < ActiveRecord::Migration[5.2]
  def change
    create_table :sharefiles  , options: ' ROW_FORMAT=DYNAMIC ' do |t|
      t.string :path
      t.string :name
      t.text :context

      t.timestamps
    end
  end
end
