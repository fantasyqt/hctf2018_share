class AddPublicToSharefile < ActiveRecord::Migration[5.2]
  def change
    add_column :sharefiles, :public, :integer
  end
end
