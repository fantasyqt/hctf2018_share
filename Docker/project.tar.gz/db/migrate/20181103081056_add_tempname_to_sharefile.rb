class AddTempnameToSharefile < ActiveRecord::Migration[5.2]
  def change
    add_column :sharefiles, :tempname, :string
  end
end
