class CreateRecommendLists < ActiveRecord::Migration[5.2]
  def change
    create_table :recommend_lists  , options: ' ROW_FORMAT=DYNAMIC ' do |t|
      t.string :url
      t.text :context
      t.integer  :read
      t.timestamps
    end
  end
end
