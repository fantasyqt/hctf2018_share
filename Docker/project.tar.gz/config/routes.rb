Rails.application.routes.draw do
  devise_for :users

  get '/home/(:page)' , to: 'home#index'
  post '/file/upload' , to: 'file#upload'
  post '/recommend/to_admin' , to: 'recommend#give_recommend'
  post '/file/Alpha_test' , to: 'file#Alpha_test'
  root to: "home#index"
  get '/recommend/show' , to: 'recommend#show'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
