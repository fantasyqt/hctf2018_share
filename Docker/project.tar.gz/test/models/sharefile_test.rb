require 'test_helper'

class SharefileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
