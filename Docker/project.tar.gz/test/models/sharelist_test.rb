require 'test_helper'

class SharelistTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
