require 'test_helper'

class RecommendListTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
