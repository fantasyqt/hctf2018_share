class RecommendList < ApplicationRecord
end
