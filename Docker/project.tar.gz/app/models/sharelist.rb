class Sharelist < ApplicationRecord
  belongs_to :sharefile

end
