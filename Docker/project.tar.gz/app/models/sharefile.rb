class Sharefile < ApplicationRecord
  has_many :sharelists

end
