class RecommendController < ApplicationController
  before_action :authenticate_user!
  before_action :authenticate_role
  before_action :authenticate_admin , :only => [:show]


# post /recommend/to_admin
  def give_recommend
    recommend = RecommendList.new
    recommend.context = params[:context]
    recommend.url = params[:url]
    recommend.read = 0
    recommend.save
    return "sucess"
  end

# get /recommend/show
  def show
    @recommend = RecommendList.where(read: 0)

    # @recommend.update_all(read: 1)
  end

end
