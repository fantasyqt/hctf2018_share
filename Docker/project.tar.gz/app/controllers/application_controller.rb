class ApplicationController < ActionController::Base

  protected

  def authenticate_admin
    unless current_user.admin?
      a = current_user
      # flash[:alert] = "Not allow!"
      redirect_to root_path
    end
  end
  def authenticate_role
    if current_user.has_role?
      a = current_user
      a.role = "guest"
      a.save
    end
  end

end
