class HomeController < ApplicationController
  def index
    if(params[:page] != nil && params[:page] != "")
      if params[:page]=="publiclist"
        @allfile = Sharefile.where(public: 1)
      else if params[:page] == "Alphatest"
             @count = Sharefile.count
             @allfile = Sharefile.joins(:sharelists).where(sharelists: {user_id: current_user.id})
           end
      end
      @page = "home/"+params[:page]
    else
      @page = "home/home"
    end
  end
end
